#!/data/data/com.icst.terminal/files/usr/bin/sh

echo "$@"
