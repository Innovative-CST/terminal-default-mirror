##
## This script is sourced by /data/data/com.icst.terminal/files/usr/bin/login before executing shell.
##
